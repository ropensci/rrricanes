#' @keywords internal
#' @useDynLib tidyr, .registration = TRUE
"_PACKAGE"
