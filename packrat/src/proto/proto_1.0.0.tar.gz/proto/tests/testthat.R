library(testthat)
library(proto)

test_check("proto")
