#ifndef RLANG_RLANG_H
#define RLANG_RLANG_H


#define R_NO_REMAP
#include <stdbool.h>
#include <Rinternals.h>

#include "cnd.h"
#include "formula.h"
#include "sexp.h"
#include "utils.h"
#include "vector.h"
#include "vector-chr.h"
#include "vector-list.h"


#endif
