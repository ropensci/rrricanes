library(testthat)
library(HURDAT)

test_check("HURDAT")