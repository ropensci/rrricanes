The source of the **knitr** website has been moved to https://github.com/yihui/yihui.name/tree/master/content/knitr
