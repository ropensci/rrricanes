#ifndef dplyr_dplyr_visitor_set_VisitorSetMixin_H
#define dplyr_dplyr_visitor_set_VisitorSetMixin_H

#include <dplyr/visitor_set/VisitorSetEqual.h>
#include <dplyr/visitor_set/VisitorSetHash.h>
#include <dplyr/visitor_set/VisitorSetLess.h>
#include <dplyr/visitor_set/VisitorSetGreater.h>

#endif // #ifndef dplyr_dplyr_visitor_set_VisitorSetMixin_H
