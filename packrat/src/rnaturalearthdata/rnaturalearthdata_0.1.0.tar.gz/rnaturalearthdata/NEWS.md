# rnaturalearthdata 0.1.0

* first CRAN submission
