[![Travis-CI Build Status](https://travis-ci.org/ropenscilabs/rnaturalearthdata.svg?branch=master)](https://travis-ci.org/ropenscilabs/rnaturalearthdata)

# rnaturalearthdata

An R package to store data for the [rnaturalearth](https://github.com/ropenscilabs/rnaturalearth) package.


[![ropensci\_footer](http://ropensci.org/public_images/github_footer.png)](http://ropensci.org)
