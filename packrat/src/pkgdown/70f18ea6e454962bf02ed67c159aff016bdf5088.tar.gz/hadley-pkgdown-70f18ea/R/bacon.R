#' Bacon
#'
#' \figure{bacon.jpg}
#'
#' @name bacon
#' @keywords internal
NULL
