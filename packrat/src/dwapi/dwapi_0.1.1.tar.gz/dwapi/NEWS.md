# 0.1.1

* Fix tests making them compliant with CRAN policies
* Improve `quickstart` vignette
* Improve accuracy of documentation and examples

# 0.1.0

* Implement all features of [data.world's REST API](https://docs.data.world/documentation/api)
* First attempted CRAN release
